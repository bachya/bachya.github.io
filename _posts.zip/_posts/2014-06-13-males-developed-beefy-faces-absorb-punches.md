---
title: Males developed beefy faces to absorb punches
author: Aaron
layout: post
permalink: /males-developed-beefy-faces-absorb-punches/
link: http://www.bbc.com/news/science-environment-27720617
dsq_thread_id:
  - 2761289510
categories:
  - Reading
tags:
  - lolz
  - science
---
Log this one under fun Friday reading material. David Carrier and Michael Morgan recently published <a title="Protective buttressing of the hominin face" href="http://onlinelibrary.wiley.com/doi/10.1111/brv.12112/abstract;jsessionid=6574E46D9D20E1230D5DCB806114FC40.f02t03" target="_blank">a paper describing how males evolved tougher faces to absorb punches</a>.

Jonathan Webb with the BBC <a title="Male faces 'buttressed against punches' by evolution" href="http://www.bbc.com/news/science-environment-27720617" target="_blank">writes</a>:

> Instead of diet, Prof Carrier and his co-author, physician Dr Michael Morgan, propose that violent competition demanded the development of these facial fortifications: what they call the &#8220;protective buttressing hypothesis&#8221;.
