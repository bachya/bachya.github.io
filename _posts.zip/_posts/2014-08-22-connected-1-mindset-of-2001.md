---
title: Connected &#35;1&#58; Mindset of 2001
author: Aaron
layout: post
permalink: /connected-1-mindset-of-2001/
link: http://overca.st/CHZ-l00CQ
dsq_thread_id:
  - 2951137847
categories:
  - Tech
tags:
  - apple
  - ios
  - ipod
---
I just listened to the first episode of <a title="Connected" href="http://relay.fm/connected" target="_blank">Connected</a>, the new Apple-based tech podcast from <a title="Relay FM" href="http://relay.fm/" target="_blank">Relay FM</a> and the continuation of tech talk goodness from <a title="Myke Hurley on Twitter" href="https://twitter.com/imyke" target="_blank">Myke Hurley</a>, <a title="Stephen Hackett on Twitter" href="https://twitter.com/ismh" target="_blank">Stephen Hackett</a>, and <a title="Federico Viticci on Twitter" href="https://twitter.com/viticci" target="_blank">Federico Viticci</a>. This particular episode is all about the history of the iPod; what an amazing history it&#8217;s been.

What really stood out to me is how I, myself, have progressed. My first generation iPod was my most treasure possession in college; now, after experiencing the comprehensive model of the iPhone, I can&#8217;t imagine carrying any sort of dedicated music/media player.
