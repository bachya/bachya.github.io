---
title: Amazon Fire Phone Flickers Out, Now Sells For 99 Cents
author: Aaron
layout: post
permalink: /amazon-fire-phone-flickers-out-now-sells-for-99-cents/
link: http://readwrite.com/2014/09/08/amazon-fire-phone-sale-99-cent-discount
dsq_thread_id:
  - 3000866504
categories:
  - Reading
  - Tech
tags:
  - amazon
  - android
  - apple
  - google
  - ios
format: link
---
<a title="Adriana Lee" href="http://readwrite.com/author/adriana-lee" target="_blank">Adrianna Lee</a> with <a title="ReadWrite" href="http://readwrite.com" target="_blank">Readwrite</a>:

> A month and a half after it released, the company has discounted the price of the handset to 99 cents on contract. That&#8217;s a big discount—99.5%, to be exact—from the $199 price tag when Amazon announced the phone in June, just three months ago.

I love my iPhone. Before it, I loved my two Android devices. But to be completely honest, I was hoping that Apple and Google would receive some serious competition from Amazon. So much for that.
