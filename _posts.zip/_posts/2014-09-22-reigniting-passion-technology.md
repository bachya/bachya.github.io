---
title: Reigniting Passion in Technology
author: Aaron
layout: post
permalink: /reigniting-passion-technology/
link: http://maildeckapp.com/2014/09/reigniting-passion-technology/
dsq_thread_id:
  - 3043949963
categories:
  - Reading
  - Tech
tags:
  - engineering
  - math
  - science
  - technology
format: link
---
Today on the <a title="MailDeck Blog" href="http://maildeckapp.com/blog/" target="_blank">MailDeck blog</a>, I wrote about <a title="Reigniting Passion in Technology" href="http://maildeckapp.com/2014/09/reigniting-passion-technology/" target="_blank">our culture&#8217;s declining &#8220;technological passion&#8221;</a> (that we build, but often without a drive other than the dollar) and what we might consider doing about it.
