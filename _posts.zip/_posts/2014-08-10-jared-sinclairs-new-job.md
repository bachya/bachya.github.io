---
title: Jared Sinclair&#8217;s New Job
author: Aaron
layout: post
permalink: /jared-sinclairs-new-job/
link: http://blog.jaredsinclair.com/post/94169163105/my-new-job
dsq_thread_id:
  - 2916475220
categories:
  - Reading
  - Tech
tags:
  - app
  - reading
  - rss
  - unread
format: link
---
[Jared Sinclair][1] on [taking a full time development job][2]:

> I’m happy to say that, starting Monday, I will be joining Bloglovin as Lead iOS Engineer. They’re a smart and fun group of men and women. It will be an honor to be a part of them. I can’t speak publicly about what we’ll be doing together, but I’m excited about it.

Although I&#8217;m happy for Jared, this part made me sad:

> Due to potential conflicts of interest between Unread and Bloglovin, I won’t be adding new features to either the iPhone or iPad version of Unread. This is by choice on my part. I like to pour myself into my work. I wouldn’t feel right doing it any other way.

I get it, but it&#8217;s still disappointing. I was in the middle of attempting to love Unread. Given that it will stay in its current state into perpetuity, that experiment has all but ended.

 [1]: http://blog.jaredsinclair.com
 [2]: http://blog.jaredsinclair.com/post/94169163105/my-new-job
